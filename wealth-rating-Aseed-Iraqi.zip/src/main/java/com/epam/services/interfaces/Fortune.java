package com.epam.services.interfaces;

public interface Fortune {
    double fortune(double cash, Integer numberOfAssets, double evaluateResponse);
}
