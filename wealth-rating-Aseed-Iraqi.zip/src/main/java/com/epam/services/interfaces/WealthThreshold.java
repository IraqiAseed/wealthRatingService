package com.epam.services.interfaces;

import java.util.Optional;

public interface WealthThreshold {
    Optional<Double> wealthThreshold();
}
